<?php
	require_once '../../koneksi.php';
	$id    = $_GET['nomor_kk'];
	$conn  = koneksi();
	$hasil = mysqli_query($conn,"DELETE FROM orang_tua WHERE nomor_kk='$id'");
	if(!$hasil) {
      echo "<script>alert('Gagal Hapus')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=./'></head><body></body></html>"; 
    }
    else {
      echo "<script>alert('Data Berhasil Dihapus')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=./'></head><body></body></html>"; 
    }
?>