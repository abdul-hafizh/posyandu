<?php 
  require_once '../../koneksi.php';

  session_start();
  if(!isset($_SESSION['username'])){    
      header('Location:../../login.php');
  }  
  $id    = $_GET['id'];
  $conn  = koneksi();
  $hasil = mysqli_query($conn,"select usia,berat_badan from detail_balita 
            inner join balita on detail_balita.id_balita = balita.id_balita
            where balita.id_balita='$id'");
  while ($data = mysqli_fetch_array($hasil)) {  
    $chartusia[]  = $data["usia"];    
    $chartberat[] = $data["berat_badan"];    
  }
?>

<?php include_once('header.php'); ?>

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="container">
        <section class="content-header">
          <h1>
            Detail Balita
            <small>Kelola Data</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="../"><i class="fa fa-dashboard"></i> Admin</a></li>
            <li><a href="./"><i class="fa fa-child"></i> Semua Balita</a></li>
            <li class="active">Detail Balita</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-4">
            <!-- Horizontal Form -->
              <?php
                  $id    = $_GET['id'];
                  $conn  = koneksi();
                  $hasil = mysqli_query($conn,"select * from detail_balita 
                            inner join balita on detail_balita.id_balita = balita.id_balita
                            inner join orang_tua on balita.nomor_kk = orang_tua.nomor_kk
                            inner join posyandu on balita.id_posyandu = posyandu.id_posyandu
                            where balita.id_balita='$id'");
                  $data  = mysqli_fetch_array($hasil);

                  $jenis = "";
                  if($data['jenis_data'] == 0){$jenis = "(Training)";}
              ?>
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Data Balita <?=$jenis?></h3>
                </div> <!-- /.box-header -->               

                <!-- form start -->
                <form class="form-horizontal" method="POST">
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Posyandu</label>
                      <div class="col-sm-7">
                        : <?=$data["nama_posyandu"]?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nomor KK</label>
                      <div class="col-sm-7">
                        : <?=$data["nomor_kk"]?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nama Ibu</label>
                      <div class="col-sm-7">
                        : <?=$data["nama_ibu"]?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nama Ayah</label>
                      <div class="col-sm-7">
                        : <?=$data["nama_ayah"]?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nama Balita</label>
                      <div class="col-sm-7">
                        : <?=$data["nama_balita"]?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Jenis Kelamin</label>
                      <div class="col-sm-7">
                        : <?php
                            $gender = "Perempuan";
                            if($data["jenis_kelamin"] == "L"){
                              $gender = "Laki-laki";
                            }
                            echo $gender;
                          ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Tanggal Lahir</label>
                      <div class="col-sm-7">
                        : <?=tgl_indo($data["tgl_lahir"])?>
                      </div>
                    </div>
                  </div> <!-- /.box-body -->

                  <div class="box-footer">
                  </div> <!-- /.box-footer -->
                </form>
              </div> <!-- /.box -->          
            </div> <!--/.col-4 --> 

            <div class="col-md-8">
              <!-- AREA CHART -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Pertumbuhan Berat Badan Balita</h3>

                  <div class="box-tools pull-right">
                    <a href="../balita/" class="btn btn-dark btn-sm" title="Kembali Ke Halaman Semua Balita">
                      <i class="fa fa-arrow-left"></i> Kembali</a>   
                  </div>
                </div>
                <div class="box-body">
                  <div class="chart">
                    <canvas id="areaChart" style="height:310px"></canvas>
                  </div>
                </div> <!-- /.box-body -->
              </div> <!-- /.box -->
            </div>       
          </div> <!-- /.row -->

          <div class="row">
            <div class="col-md-4">
            <!-- Horizontal Form -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Update Balita</h3>
                </div> <!-- /.box-header -->

                <!-- form start -->
                <form class="form-horizontal" action="update.php" method="POST">                  
                  <input type="hidden" name="id_balita" value="<?=$_GET['id'];?>">
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Usia (Bulan)</label>
                      <div class="col-sm-7">
                        <input type="number" min="0" class="form-control" name="usia" placeholder="Usia Balita" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Berat (Kg)</label>
                      <div class="col-sm-7">
                        <input type="number" min="0" max="50" step="any" class="form-control" name="berat_badan" placeholder="Berat Balita" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Status Gizi</label>
                      <div class="col-sm-7">
                        <select class="form-control" name="status_gizi" required>
                          <option value="" readonly>Pilih</option>
                          <option value="1">Gizi Lebih</option>
                          <option value="2">Gizi Baik</option>
                          <option value="3">Gizi Kurang</option>
                          <option value="4">Gizi Buruk</option>
                        </select>
                      </div>
                    </div>
                   
                  </div> <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="reset" class="btn btn-default">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-success pull-right">Simpan</button>
                  </div> <!-- /.box-footer -->
                </form>
              </div> <!-- /.box -->          
            </div> <!--/.col-4 --> 

            <div class="col-md-8">
            <?php
              if($data["usia"] != "") {
            ?>
            <?php
                $id    = $_GET['id'];
                $conn  = koneksi();
                $i     = 1;
                $hasil = mysqli_query($conn,"select * from detail_balita 
                          inner join balita on detail_balita.id_balita = balita.id_balita
                          where balita.id_balita='$id'");
                while ($data = mysqli_fetch_array($hasil)) {  
                  $gizi = "Gizi Lebih"; 
                  $warna = "callout-info";
                  if($data["status_gizi"] == 2){
                    $gizi = "Gizi Baik"; 
                    $warna = "callout-success";
                  }elseif($data["status_gizi"] == 3){
                    $gizi = "Gizi Kurang"; 
                    $warna = "callout-warning";
                  }elseif($data["status_gizi"] == 4){
                    $gizi = "Gizi Buruk"; 
                    $warna = "callout-danger";
                  }  
            ?>
              <div class="col-md-4">
                <div class="callout <?=$warna?>">
                  <a href="hapus_detail.php?id=<?=$data['id_detail'];?>&balita=<?=$data['id_balita'];?>" style="color:grey" class="btn btn-default btn-sm pull-right" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" title="Hapus Data"><i class="fa fa-trash"></i></a>                    
                  <h4>Nomor Urut <?=$i++?></h4>                  
                  <p>
                    Usia : <?=$data["usia"]?> Bulan<br/>
                    Berat Badan : <?=$data["berat_badan"]?> Kg<br/>
                    Status Gizi : <?=$gizi?><br/>
                    Tanggal : <?=tgl_indo($data["tgl_update"])?>
                  </p>
                </div> <!-- callout --> 
              </div> <!--/.col-6 -->
            <?php 
                } 
              }
            ?>
            </div> <!--/.col-8 -->
          </div> <!-- row -->         
        </section> <!-- /.content -->
      </div> <!-- /.container -->
    </div> <!-- /.content-wrapper -->

    <footer class="main-footer">
      <div class="container">
        <div class="pull-right hidden-xs">
          version 1.0.0 | Developed by <a href="" title="Developer">Abdul Hafizh</a>
        </div>
        <strong>Copyright &copy; 2018 <a href="https://adminlte.io" target="_blank">Almsaeed Studio</a>.</strong>
      </div> <!-- /.container -->
    </footer>
  </div> <!-- ./wrapper -->

  <script src="../../_assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="../../_assets/bower_components/chart.js/Chart.js"></script>
  <script src="../../_assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../../_assets/dist/js/adminlte.min.js"></script>
  <script>
    $(function () {
      /* ChartJS
       * -------
       * Here we will create a few charts using ChartJS
       */

      //--------------
      //- AREA CHART -
      //--------------

      // Get context with jQuery - using jQuery's .get() method.
      var areaChartCanvas = $('#areaChart').get(0).getContext('2d')
      // This will get the first returned node in the jQuery collection.
      var areaChart       = new Chart(areaChartCanvas)

      var areaChartData = {
        labels  : <?=json_encode($chartusia)?>,
        datasets: [
          {
            label               : 'Digital Goods',
            fillColor           : 'rgba(60,141,188,0.9)',
            strokeColor         : 'rgba(60,141,188,0.8)',
            pointColor          : '#3b8bba',
            pointStrokeColor    : 'rgba(60,141,188,1)',
            pointHighlightFill  : '#fff',
            pointHighlightStroke: 'rgba(60,141,188,1)',
            data                : <?=json_encode($chartberat)?>
          }
        ]
      }

      var areaChartOptions = {
        //Boolean - If we should show the scale at all
        showScale               : true,
        //Boolean - Whether grid lines are shown across the chart
        scaleShowGridLines      : false,
        //String - Colour of the grid lines
        scaleGridLineColor      : 'rgba(0,0,0,.05)',
        //Number - Width of the grid lines
        scaleGridLineWidth      : 1,
        //Boolean - Whether to show horizontal lines (except X axis)
        scaleShowHorizontalLines: true,
        //Boolean - Whether to show vertical lines (except Y axis)
        scaleShowVerticalLines  : true,
        //Boolean - Whether the line is curved between points
        bezierCurve             : true,
        //Number - Tension of the bezier curve between points
        bezierCurveTension      : 0.3,
        //Boolean - Whether to show a dot for each point
        pointDot                : false,
        //Number - Radius of each point dot in pixels
        pointDotRadius          : 4,
        //Number - Pixel width of point dot stroke
        pointDotStrokeWidth     : 1,
        //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
        pointHitDetectionRadius : 20,
        //Boolean - Whether to show a stroke for datasets
        datasetStroke           : true,
        //Number - Pixel width of dataset stroke
        datasetStrokeWidth      : 2,
        //Boolean - Whether to fill the dataset with a color
        datasetFill             : true,
        //String - A legend template
        legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
        //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
        maintainAspectRatio     : true,
        //Boolean - whether to make the chart responsive to window resizing
        responsive              : true
      }

      areaChart.Line(areaChartData, areaChartOptions)
    })
  </script>
</body>
</html>