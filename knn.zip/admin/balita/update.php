<?php
require_once '../../koneksi.php';
$conn  = koneksi();

session_start();
if(!isset($_SESSION['username'])){    
    header('Location:../../login.php');
}  

if(isset($_POST["simpan"])){
  $id     = $_POST['id_balita'];
  $usia   = $_POST['usia'];
  $berat  = $_POST['berat_badan'];
  $status = $_POST['status_gizi'];
  $tgl    = date('Y-m-d');

  $level = mysqli_query($conn,"select usia from detail_balita where id_balita='$id'");
  $datas = mysqli_fetch_array($level);

  if($datas['usia'] == ""){
    $sql   = "update detail_balita set usia='$usia',berat_badan='$berat',
              status_gizi='$status',tgl_update='$tgl' where id_balita='$id'";    
  } else {
    $count = mysqli_query($conn,"select count(nomor_urut) as urut from detail_balita where id_balita='$id'");
    $data  = mysqli_fetch_array($count);
    $urut  = $data['urut']+1;

    $sql   = "insert into detail_balita (id_balita,usia,berat_badan,status_gizi,tgl_update,nomor_urut) 
              values('$id','$usia','$berat','$status','$tgl','$urut')";    
  }

  $hasil = mysqli_query($conn, $sql);
  if(!$hasil) {
    echo "<script>alert('Gagal Simpan')</script>";
    echo "<html><head><meta http-equiv='refresh' content='0;url=detail.php?id=$id'></head><body></body></html>"; 
  }
  else {
    echo "<script>alert('Data Berhasil Disimpan')</script>";
    echo "<html><head><meta http-equiv='refresh' content='0;url=detail.php?id=$id'></head><body></body></html>"; 
  }
}

?>