<?php
	require_once '../../koneksi.php';
  $id   = $_GET['id'];
  $ba   = $_GET['balita'];
	$conn = koneksi();

  $count = mysqli_query($conn,"select count(nomor_urut) as urut from detail_balita where id_balita='$ba'");
  $data  = mysqli_fetch_array($count);

  if($data['urut'] == 1){
    $hasil = mysqli_query($conn,"update detail_balita set usia=null,berat_badan=null,status_gizi=null,nomor_urut=1 where id_balita='$ba'");
  } else {
    $hasil = mysqli_query($conn,"DELETE FROM detail_balita WHERE id_detail='$id'");
  }
	
	if(!$hasil) {
      echo "<script>alert('Gagal Hapus')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=detail.php?id=$ba'></head><body></body></html>"; 
    }
    else {
      echo "<script>alert('Data Berhasil Dihapus')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=detail.php?id=$ba'></head><body></body></html>"; 
    }
?>