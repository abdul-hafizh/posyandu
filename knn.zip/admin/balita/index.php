<?php 
  require_once '../../koneksi.php';

  session_start();
  if(!isset($_SESSION['username'])){    
      header('Location:../../login.php');
  }  

  if(isset($_POST["simpan"])){
    $nokk   = $_POST['nomor_kk'];
    $idpos  = $_POST['id_posyandu'];
    $nama   = $_POST['nama_balita'];
    $gender = $_POST['jenis_kelamin'];
    $tgl    = $_POST['tgl_lahir'];

    $conn  = koneksi();
    $sql   = "insert into balita (nomor_kk,id_posyandu,nama_balita,jenis_kelamin,tgl_lahir) 
              values('$nokk','$idpos','$nama','$gender','$tgl')";    
    $hasil = mysqli_query($conn, $sql);

    $select = mysqli_query($conn,"select max(id_balita) as maksimum from balita");
    $data   = mysqli_fetch_array($select);

    $idd    = $data['maksimum'];
    $update = date('Y-m-d');
    $sql2   = "insert into detail_balita (id_balita,tgl_update) values('$idd','$update')";
    $hasil2 = mysqli_query($conn, $sql2);

    if(!$hasil) {
      echo "<script>alert('Gagal Simpan')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=./'></head><body></body></html>"; 
    }
    else {
      echo "<script>alert('Data Berhasil Disimpan')</script>";
      echo "<html><head><meta http-equiv='refresh' content='0;url=./'></head><body></body></html>"; 
    }
  }
?>

<?php include_once('header.php'); ?>

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="container">
        <section class="content-header">
          <h1>
            Semua Balita
            <small>Kelola Data</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="../"><i class="fa fa-dashboard"></i> Admin</a></li>
            <li class="active">Semua Balita</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-4">
            <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Tambah Balita</h3>
                </div> <!-- /.box-header -->

                <!-- form start -->
                <form class="form-horizontal" method="POST">
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Posyandu</label>
                      <div class="col-sm-7">
                        <select class="form-control select2" name="id_posyandu" required>
                          <option value="" readonly >Pilih Posyandu</option>
                          <?php                
                            $conn = koneksi();                   
                            $sql  ="select * from posyandu";
                            $hasil = mysqli_query($conn, $sql);
                            while ($r = mysqli_fetch_array($hasil)) { 
                          ?>
                          <option value="<?=$r['id_posyandu']?>"><?=$r['nama_posyandu']?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nomor KK</label>
                      <div class="col-sm-7">
                        <select class="form-control select2" name="nomor_kk" required>
                          <option value="" readonly >Pilih Kartu Keluarga</option>
                          <?php                
                            $conn = koneksi();                   
                            $sql  ="select * from orang_tua";
                            $hasil = mysqli_query($conn, $sql);
                            while ($r = mysqli_fetch_array($hasil)) { 
                          ?>
                          <option value="<?=$r['nomor_kk']?>"><?=$r['nomor_kk']?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Nama Balita</label>
                      <div class="col-sm-7">
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-child"></i>
                          </div>
                          <input type="text" class="form-control" name="nama_balita" placeholder="Nama Balita" required>
                        </div>                        
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Jenis Kelamin</label>
                      <div class="col-sm-7">
                        <select class="form-control select2" name="jenis_kelamin" required>
                          <option value="" readonly >Pilih Jenis Kelamin</option>                          
                          <option value="L">Laki-laki</option>
                          <option value="P">Perempuan</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-4 control-label">Tanggal Lahir</label>
                      <div class="col-sm-7">
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" class="form-control" id="datepicker" name="tgl_lahir" placeholder="Tanggal Lahir" required>
                        </div>
                      </div>
                    </div>
                  </div> <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="reset" class="btn btn-default">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-success pull-right">Simpan</button>
                  </div> <!-- /.box-footer -->
                </form>
              </div> <!-- /.box -->          
            </div> <!--/.col-4 -->

            <div class="col-md-8">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Data Semua Balita</h3>
                </div> <!-- /.box-header -->

                <div class="box-body">
                  <table id="posyandu" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Balita</th>
                        <th>Nama Ibu</th>
                        <th>Jenis Kelamin</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php                        
                        $conn = koneksi();                   
                        $sql =  "select * from balita
                                  inner join orang_tua on balita.nomor_kk=orang_tua.nomor_kk";
                                  
                        $hasil = mysqli_query($conn, $sql);                      
                        $no    = 1;
                        while ($data = mysqli_fetch_array($hasil)) {                        
                          $gender="";
                          if($data["jenis_kelamin"]=="L"){
                              $gender="Laki-laki";
                          }
                          if($data["jenis_kelamin"]=="P"){
                              $gender="Perempuan";
                          }
                      ?>
                      <tr>
                        <td><?=$no++?></td>
                        <td><?=$data["nama_balita"]?></td>
                        <td><?=$data["nama_ibu"]?></td>
                        <td><?=$gender?></td>
                        <td>
                          <a href="detail.php?id=<?=$data['id_balita'];?>" class="btn btn-sm btn-primary" title="Detail Data"><i class="fa fa-search"></i></a>
                          <a href="edit.php?id=<?=$data['id_balita'];?>" class="btn btn-sm btn-warning" title="Edit Data"><i class="fa fa-pencil"></i></a>
                          <a href="hapus.php?id=<?=$data['id_balita'];?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" title="Hapus Data"><i class="fa fa-trash"></i></a>
                        </td>
                      </tr>
                      <?php } ?>

                    </tbody>
                  </table>
                </div> <!-- /.box-body -->
               
              </div> <!-- /.box -->          
            </div> <!--/.col-8 -->
          </div> <!-- /.row -->
         
        </section> <!-- /.content -->
      </div> <!-- /.container -->
    </div> <!-- /.content-wrapper -->

    <footer class="main-footer">
      <div class="container">
        <div class="pull-right hidden-xs">
          version 1.0.0 | Developed by <a href="" title="Developer">Abdul Hafizh</a>
        </div>
        <strong>Copyright &copy; 2018 <a href="https://adminlte.io" target="_blank">Almsaeed Studio</a>.</strong>
      </div> <!-- /.container -->
    </footer>
  </div> <!-- ./wrapper -->

  <script src="../../_assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="../../_assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../../_assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="../../_assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script src="../../_assets/bower_components/select2/dist/js/select2.full.min.js"></script>
  <script src="../../_assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
  <script src="../../_assets/dist/js/adminlte.min.js"></script>
  <script>
    $(function () {
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd',
        todayHighlight:true
      })
      $('.select2').select2()
      $('#posyandu').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'info'        : true,
        'autoWidth'   : true,
        'columnDefs': [
          { 
            "targets": [ 3 ], 
            "orderable": false
          },
          { 
            "targets": [ 4 ], 
            "searchable": false,
            "orderable": false
          },
          { 
            "targets": [ 0 ], 
            "searchable": false
          },
        ]
      })
    })
  </script>
</body>
</html>