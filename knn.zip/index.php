<?php 
  require_once 'koneksi.php'; 
  $conn   = koneksi();
  $hasil  = mysqli_query($conn,"select count(status_gizi) as jumlah from detail_balita where status_gizi='1'");
  $datas  = mysqli_fetch_array($hasil);
  $array  = array(65,90,75,81,95,105,130);
  $jumlah = json_encode($array);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Selamat Datang</title>
  
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="_assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="_assets/bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="_assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="_assets/bower_components/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="_assets/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="_assets/dist/css/skins/_all-skins.min.css">

  <!-- Pace Loader -->
  <link rel="stylesheet" href="_assets/pace/pace-white-minimal.css" />
  <script src="_assets/pace/pace.min.js"></script>
  
</head>

<body class="hold-transition skin-blue layout-top-nav">
  <div class="wrapper">
    <header class="main-header">
      <nav class="navbar navbar-static-top">
        <div class="container">
          <div class="navbar-header">
            <a href="./" class="navbar-brand"><b>Selamat</b> Datang</a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
              <i class="fa fa-bars"></i>
            </button>
          </div>

          <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav">              
              <li><a href="login.php" title="Masuk">Masuk <i class="fa fa-sign-in"></i></a></li>
            </ul>
          </div> <!-- /.navbar-collapse -->
        </div> <!-- /.container-fluid -->
      </nav>
    </header>

    <!-- Full Width Column -->
    <div class="content-wrapper">
      <div class="container">
        <section class="content-header">
          <h1>
            Dashboard
            <small>Halaman Utama</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="./"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Selamat Datang</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-child"></i></span>
                <?php
                  $conn  = koneksi();
                  $hasil = mysqli_query($conn,"select count(status_gizi) as jumlah from detail_balita where status_gizi='1'");
                  $lebih = mysqli_fetch_array($hasil);
                ?>
                <div class="info-box-content">
                  <span class="info-box-text">Gizi Lebih</span>
                  <span class="info-box-number" style="font-size: 30px;"><?=$lebih['jumlah']?></span>
                </div> <!-- /.info-box-content -->
              </div> <!-- /.info-box -->
            </div> <!-- /.col -->

            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-child"></i></span>
                <?php
                  $conn  = koneksi();
                  $hasil = mysqli_query($conn,"select count(status_gizi) as jumlah from detail_balita where status_gizi='2'");
                  $baik = mysqli_fetch_array($hasil);
                ?>
                <div class="info-box-content">
                  <span class="info-box-text">Gizi Baik</span>
                  <span class="info-box-number" style="font-size: 30px;"><?=$baik['jumlah']?></span>
                </div> <!-- /.info-box-content -->
              </div> <!-- /.info-box -->
            </div> <!-- /.col -->

            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="fa fa-child"></i></span>
                <?php
                  $conn  = koneksi();
                  $hasil = mysqli_query($conn,"select count(status_gizi) as jumlah from detail_balita where status_gizi='3'");
                  $kurang = mysqli_fetch_array($hasil);
                ?>
                <div class="info-box-content">
                  <span class="info-box-text">Gizi Kurang</span>
                  <span class="info-box-number" style="font-size: 30px;"><?=$kurang['jumlah']?></span>
                </div> <!-- /.info-box-content -->
              </div> <!-- /.info-box -->
            </div> <!-- /.col -->

            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-child"></i></span>
                <?php
                  $conn  = koneksi();
                  $hasil = mysqli_query($conn,"select count(status_gizi) as jumlah from detail_balita where status_gizi='4'");
                  $buruk = mysqli_fetch_array($hasil);
                ?>
                <div class="info-box-content">
                  <span class="info-box-text">Gizi Buruk</span>
                  <span class="info-box-number" style="font-size: 30px;"><?=$buruk['jumlah']?></span>
                </div> <!-- /.info-box-content -->
              </div> <!-- /.info-box -->
            </div> <!-- /.col -->
            
          </div> <!-- /.row -->

          <div class="row">
            <div class="col-md-12">
              <!-- AREA CHART -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Jumlah Balita</h3>

                  <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body">
                  <div class="chart">
                    <canvas id="areaChart" style="height:250px"></canvas>
                  </div>
                </div> <!-- /.box-body -->
              </div> <!-- /.box -->
            </div> <!-- /.col -->           
          </div> <!-- /.row -->
         
        </section> <!-- /.content -->
      </div> <!-- /.container -->
    </div> <!-- /.content-wrapper -->

    <footer class="main-footer">
      <div class="container">
        <div class="pull-right hidden-xs">
          version 1.0.0 | Developed by <a href="" title="Developer">Abdul Hafizh</a>
        </div>
        <strong>Copyright &copy; 2018 <a href="https://adminlte.io" target="_blank">Almsaeed Studio</a>.</strong>
      </div> <!-- /.container -->
    </footer>
  </div> <!-- ./wrapper -->

  <script src="_assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="_assets/bower_components/chart.js/Chart.js"></script>
  <script src="_assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="_assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="_assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script src="_assets/bower_components/select2/dist/js/select2.full.min.js"></script>
  <script src="_assets/dist/js/adminlte.min.js"></script>
  <script>
    $(function () {
      /* ChartJS
       * -------
       * Here we will create a few charts using ChartJS
       */

      //--------------
      //- AREA CHART -
      //--------------

      // Get context with jQuery - using jQuery's .get() method.
      var areaChartCanvas = $('#areaChart').get(0).getContext('2d')
      // This will get the first returned node in the jQuery collection.
      var areaChart       = new Chart(areaChartCanvas)

      var areaChartData = {
        labels  : ['2013', '2014', '2015', '2016', '2017', '2018', '2019'],
        datasets: [
          {
            label               : 'Digital Goods',
            fillColor           : 'rgba(60,141,188,0.9)',
            strokeColor         : 'rgba(60,141,188,0.8)',
            pointColor          : '#3b8bba',
            pointStrokeColor    : 'rgba(60,141,188,1)',
            pointHighlightFill  : '#fff',
            pointHighlightStroke: 'rgba(60,141,188,1)',
            data                : <?=$jumlah?>
          }
        ]
      }

      var areaChartOptions = {
        //Boolean - If we should show the scale at all
        showScale               : true,
        //Boolean - Whether grid lines are shown across the chart
        scaleShowGridLines      : false,
        //String - Colour of the grid lines
        scaleGridLineColor      : 'rgba(0,0,0,.05)',
        //Number - Width of the grid lines
        scaleGridLineWidth      : 1,
        //Boolean - Whether to show horizontal lines (except X axis)
        scaleShowHorizontalLines: true,
        //Boolean - Whether to show vertical lines (except Y axis)
        scaleShowVerticalLines  : true,
        //Boolean - Whether the line is curved between points
        bezierCurve             : true,
        //Number - Tension of the bezier curve between points
        bezierCurveTension      : 0.3,
        //Boolean - Whether to show a dot for each point
        pointDot                : false,
        //Number - Radius of each point dot in pixels
        pointDotRadius          : 4,
        //Number - Pixel width of point dot stroke
        pointDotStrokeWidth     : 1,
        //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
        pointHitDetectionRadius : 20,
        //Boolean - Whether to show a stroke for datasets
        datasetStroke           : true,
        //Number - Pixel width of dataset stroke
        datasetStrokeWidth      : 2,
        //Boolean - Whether to fill the dataset with a color
        datasetFill             : true,
        //String - A legend template
        legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
        //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
        maintainAspectRatio     : true,
        //Boolean - whether to make the chart responsive to window resizing
        responsive              : true
      }

      areaChart.Line(areaChartData, areaChartOptions)
    })
  </script>
</body>
</html>